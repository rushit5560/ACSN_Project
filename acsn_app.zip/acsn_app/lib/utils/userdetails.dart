class UserDetails{
  static String username = "";
  static String userPassword = "";
}
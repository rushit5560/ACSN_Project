class FontFamilyText {
  static String roboto = "Roboto";
  static String robotoMedium = "Roboto-Medium";
}

import 'package:flutter/material.dart';

const defaultRadius = 14.0;
const defaultPadding = 13.0;
const primaColor = Color(0XFF65b804);
const secondary = Color(0XFFf5f8fd);
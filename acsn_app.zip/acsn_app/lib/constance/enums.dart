enum QuestionOption {yes, no}

enum ComingFromScreen {todayJobs, futureJobs, datePassedJobs}

enum PaymentSuccessOption {yes, no, noSelected}
class AppImages {
  static const rootPath = 'assets/images';

  static const logoImage = "$rootPath/acsn_logo.png";
}

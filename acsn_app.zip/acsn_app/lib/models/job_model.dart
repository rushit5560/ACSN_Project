
class JobModel {
  bool changeSchedule;
  String fieldWorkerNote;
  String internalNote;

  JobModel({required this.changeSchedule, required this.fieldWorkerNote, required this.internalNote});
}